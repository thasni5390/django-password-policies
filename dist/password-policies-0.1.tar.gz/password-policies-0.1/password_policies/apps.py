from django.apps import AppConfig


class PasswordPoliciesConfig(AppConfig):
    name = 'password_policies'
