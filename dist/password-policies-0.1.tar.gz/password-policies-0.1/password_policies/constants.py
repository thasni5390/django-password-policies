SESSION_KEY_CHECKED = '_password_policies_last_checked'
SESSION_KEY_EXPIRED = '_password_policies_expired'
SESSION_KEY_LAST = '_password_policies_last_changed'
SESSION_KEY_REQUIRED = '_password_policies_change_required'
